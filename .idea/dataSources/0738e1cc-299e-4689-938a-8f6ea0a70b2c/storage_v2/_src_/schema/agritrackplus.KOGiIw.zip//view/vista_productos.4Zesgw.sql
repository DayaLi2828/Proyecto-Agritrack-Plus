create definer = agriplus@localhost view vista_productos as
select `agritrackplus`.`productos`.`nombre`            AS `nombre`,
       `agritrackplus`.`productos`.`unidad_medida`     AS `unidad_medida`,
       `agritrackplus`.`productos`.`precio`            AS `precio`,
       `agritrackplus`.`productos`.`fecha_compra`      AS `fecha_compra`,
       `agritrackplus`.`productos`.`fecha_vencimiento` AS `fecha_vencimiento`,
       `agritrackplus`.`productos`.`estado`            AS `estado`,
       `agritrackplus`.`productos`.`tipo_producto_id`  AS `tipo_producto_id`
from `agritrackplus`.`productos`;

