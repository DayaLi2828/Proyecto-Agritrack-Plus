create definer = agriplus@localhost view vista_usuarios_estado as
select `agritrackplus`.`usuarios`.`id`        AS `id`,
       `agritrackplus`.`usuarios`.`nombre`    AS `nombre`,
       `agritrackplus`.`usuarios`.`documento` AS `documento`,
       `agritrackplus`.`usuarios`.`direccion` AS `direccion`,
       `agritrackplus`.`usuarios`.`estado`    AS `estado`
from `agritrackplus`.`usuarios`
where (`agritrackplus`.`usuarios`.`estado` = 'Activo');

