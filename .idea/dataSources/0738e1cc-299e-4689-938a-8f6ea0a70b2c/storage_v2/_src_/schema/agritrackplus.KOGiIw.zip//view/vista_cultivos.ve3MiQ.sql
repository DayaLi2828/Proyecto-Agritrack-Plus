create definer = agriplus@localhost view vista_cultivos as
select `agritrackplus`.`cultivos`.`id`            AS `id`,
       `agritrackplus`.`cultivos`.`nombre`        AS `nombre`,
       `agritrackplus`.`cultivos`.`fecha_siembra` AS `fecha_siembra`,
       `agritrackplus`.`cultivos`.`fecha_cosecha` AS `fecha_cosecha`,
       `agritrackplus`.`cultivos`.`ciclo`         AS `ciclo`
from `agritrackplus`.`cultivos`;

