create definer = agriplus@localhost view vista_tipo_producto as
select `agritrackplus`.`tipo_producto`.`tipo_nombre` AS `tipo_nombre`
from `agritrackplus`.`tipo_producto`;

