create definer = agriplus@localhost view vista_pagos as
select `agritrackplus`.`pagos`.`usuario_id` AS `usuario_id`,
       `agritrackplus`.`pagos`.`fecha_pago` AS `fecha_pago`,
       `agritrackplus`.`pagos`.`estado`     AS `estado`,
       `agritrackplus`.`pagos`.`pago`       AS `pago`
from `agritrackplus`.`pagos`;

